<?php
session_start();
$qr_file_path="URL";
$con=mysqli_connect('HOST','USERNAME','PASSWORD','DATABASE');
?>