
<footer class="footer"> © 2020  <a href="domain.com">domain.com </a>
            </footer>
         </div>
      </div>
      <script src="assets/plugins/jquery/dist/jquery.min.js"></script>
      <script src="assets/plugins/popper.js/dist/umd/popper.min.js"></script>
      <script src="assets/plugins/bootstrap/dist/js/bootstrap.min.js"></script>
      <script src="js/app-style-switcher.js"></script>
      <script src="js/waves.js"></script>
      <script src="js/sidebarmenu.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>