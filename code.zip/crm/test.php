<?php
//$pwd="admin";
//echo password_hash($pwd,PASSWORD_DEFAULT);
?>